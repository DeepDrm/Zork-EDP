#include <iostream>
#include "mainwindow.h"
#include <QApplication>

using namespace std;
#include "ZorkUL.h"

int main(int argc, char* argv[]) {
    QApplication a(argc, argv);

    MainWindow w;
    w.setVisible(true);
    w.show();

    ZorkUL temp;
    temp.play();

    return a.exec();
}
